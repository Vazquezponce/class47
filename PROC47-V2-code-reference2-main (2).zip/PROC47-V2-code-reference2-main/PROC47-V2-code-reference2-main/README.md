# Dispara al zombi etapa 3
## Enlace de referencia 2 para la clase PROC47V2.